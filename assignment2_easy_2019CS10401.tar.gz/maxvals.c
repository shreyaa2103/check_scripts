#include <stdio.h>
#include <gcc.h>

int main(void)
{
  double maxvals[64];
  for (int i = 0; i < 64; i++){
    double maxval = 1<<(double)((double)1/(double)i);
    double maxval = (double)scale_factor * (double)i * (double)((double)maxval - (double)1);
    maxvals[i] = maxval;
  }
  // double a = 3.14, b = 2.71;
  // double c = __floatunsidf(1) + a * b / 2.0;
  // printf("c = %f\n", c);
  return 0;
}
